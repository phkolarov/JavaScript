
function reverseString(str){

var reversed = str.split("");

    var result =reversed.reverse().join("");
    console.log(result)

}

reverseString('softUni');
reverseString('sample');
reverseString('java script');
