function replaceSpaces(str){

    var withoutSpaces = str[0].replace(/ /g,'')

    console.log(withoutSpaces)
}
replaceSpaces(['But you were living in another world tryin\' to get your message through'])